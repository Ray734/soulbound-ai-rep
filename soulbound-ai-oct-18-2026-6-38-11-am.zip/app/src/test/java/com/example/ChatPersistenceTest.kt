package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChatPersistenceTest {

    private lateinit var database: AppDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        database.close()
    }

    @Test
    fun testChatMessagePersistenceAndOrdering() {
        runBlocking {
            val dao = database.chatMessageDao()

            // 1. Initial database should be empty
            val initialMessages = dao.getAllMessagesList()
            assertTrue(initialMessages.isEmpty())

            // 2. Insert User message
            val userMsgId = dao.insertMessage(
                ChatMessageEntity(
                    sender = "USER",
                    cipherText = "encrypted_user_text_hello",
                    iv = "iv_user_1",
                    timestamp = 1000L
                )
            )
            assertTrue(userMsgId > 0)

            // 3. Insert AI Companion response
            val aiMsgId = dao.insertMessage(
                ChatMessageEntity(
                    sender = "COMPANION",
                    cipherText = "encrypted_ai_text_hello_darling",
                    iv = "iv_ai_1",
                    timestamp = 1005L,
                    recalledMemorySnippet = "Loves deep evening chats"
                )
            )
            assertTrue(aiMsgId > 0)

            // 4. Retrieve messages via Flow (as UI / ViewModel does)
            val loadedMessages = dao.getAllMessages().first()
            assertEquals(2, loadedMessages.size)

            // 5. Verify ordering: chronological (User message first, AI message second)
            assertEquals("USER", loadedMessages[0].sender)
            assertEquals("encrypted_user_text_hello", loadedMessages[0].cipherText)
            assertEquals(1000L, loadedMessages[0].timestamp)

            assertEquals("COMPANION", loadedMessages[1].sender)
            assertEquals("encrypted_ai_text_hello_darling", loadedMessages[1].cipherText)
            assertEquals(1005L, loadedMessages[1].timestamp)
            assertEquals("Loves deep evening chats", loadedMessages[1].recalledMemorySnippet)

            // 6. Verify getRecentMessages retrieves latest message
            val recent = dao.getRecentMessages(1)
            assertEquals(1, recent.size)
            assertEquals("COMPANION", recent[0].sender)
        }
    }

    @Test
    fun testRestartSimulationLoadsExistingMessages() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val dbFile = context.getDatabasePath("test_chat_restart.db")
            dbFile.delete()

            // Open DB instance 1
            val db = Room.databaseBuilder(context, AppDatabase::class.java, "test_chat_restart.db")
                .allowMainThreadQueries()
                .build()

            val dao = db.chatMessageDao()
            dao.insertMessage(
                ChatMessageEntity(
                    sender = "USER",
                    cipherText = "hello_before_restart",
                    iv = "iv1",
                    timestamp = 2000L
                )
            )
            dao.insertMessage(
                ChatMessageEntity(
                    sender = "COMPANION",
                    cipherText = "reply_before_restart",
                    iv = "iv2",
                    timestamp = 2005L
                )
            )

            // Simulate app shutdown / close DB
            db.close()

            // Simulate app restart / reopen DB instance 2
            val restartedDb = Room.databaseBuilder(context, AppDatabase::class.java, "test_chat_restart.db")
                .allowMainThreadQueries()
                .build()
            val restartedDao = restartedDb.chatMessageDao()

            // Verify previous messages are loaded when app restarts
            val persistedMessages = restartedDao.getAllMessagesList()
            assertEquals(2, persistedMessages.size)
            assertEquals("USER", persistedMessages[0].sender)
            assertEquals("hello_before_restart", persistedMessages[0].cipherText)
            assertEquals("COMPANION", persistedMessages[1].sender)
            assertEquals("reply_before_restart", persistedMessages[1].cipherText)

            restartedDb.close()
            dbFile.delete()
        }
    }
}
