package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val displayName: String, val description: String, val previewColor: Color) {
    MIDNIGHT_ROSE("Midnight Rose", "Velvet dark violet & warm rose", RosePrimary),
    CLAUDE_WARMTH("Claude Warmth", "Terracotta, burnt coral & warm amber", ClaudeTerracotta),
    GEMINI_NEBULA("Gemini Nebula", "Cosmic deep navy & radiant electric blue", GeminiBlue),
    CYBER_AMETHYST("Cyber Amethyst", "Electric neon magenta & deep obsidian", CyberMagenta),
    EMERALD_SERENITY("Emerald Serenity", "Deep forest jade, sage & soft mint", EmeraldPrimary)
}

val MidnightRoseScheme = darkColorScheme(
    primary = RosePrimary,
    onPrimary = RoseOnPrimary,
    primaryContainer = RoseContainer,
    onPrimaryContainer = RoseOnContainer,
    secondary = LavenderSecondary,
    onSecondary = LavenderOnSecondary,
    secondaryContainer = LavenderContainer,
    onSecondaryContainer = LavenderOnContainer,
    tertiary = PeachTertiary,
    onTertiary = Color(0xFF451E07),
    tertiaryContainer = PeachContainer,
    onTertiaryContainer = PeachOnContainer,
    background = MidnightBackground,
    onBackground = MidnightOnBackground,
    surface = MidnightSurface,
    onSurface = MidnightOnSurface,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = MidnightOnSurfaceVariant,
    outline = Color(0xFF6B5D7A),
    outlineVariant = Color(0xFF3F354D)
)

val ClaudeWarmthScheme = darkColorScheme(
    primary = ClaudeTerracotta,
    onPrimary = ClaudeOnTerracotta,
    primaryContainer = ClaudeTerracottaContainer,
    onPrimaryContainer = ClaudeOnTerracottaContainer,
    secondary = ClaudeAmberSecondary,
    onSecondary = Color(0xFF381E05),
    secondaryContainer = Color(0xFF4E2B0C),
    onSecondaryContainer = Color(0xFFFFDBCF),
    tertiary = ClaudeSandTertiary,
    onTertiary = Color(0xFF2E2215),
    background = ClaudeParchmentDark,
    onBackground = ClaudeOnParchment,
    surface = ClaudeSurfaceDark,
    onSurface = ClaudeOnParchment,
    surfaceVariant = ClaudeSurfaceVariant,
    onSurfaceVariant = Color(0xFFDCCFC5),
    outline = Color(0xFF755E4C),
    outlineVariant = Color(0xFF473A30)
)

val GeminiNebulaScheme = darkColorScheme(
    primary = GeminiBlue,
    onPrimary = GeminiOnBlue,
    primaryContainer = GeminiBlueContainer,
    onPrimaryContainer = GeminiOnBlueContainer,
    secondary = GeminiCyanSecondary,
    onSecondary = Color(0xFF03334A),
    secondaryContainer = Color(0xFF084869),
    onSecondaryContainer = Color(0xFFC7EEFF),
    tertiary = GeminiVioletTertiary,
    onTertiary = Color(0xFF2D1854),
    background = GeminiCosmicBackground,
    onBackground = GeminiOnBackground,
    surface = GeminiCosmicSurface,
    onSurface = GeminiOnBackground,
    surfaceVariant = GeminiCosmicSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF4B6187),
    outlineVariant = Color(0xFF24324D)
)

val CyberAmethystScheme = darkColorScheme(
    primary = CyberMagenta,
    onPrimary = CyberOnMagenta,
    primaryContainer = Color(0xFF4E005C),
    onPrimaryContainer = Color(0xFFFFD7FE),
    secondary = CyberPurpleSecondary,
    onSecondary = Color(0xFF28006E),
    secondaryContainer = Color(0xFF3C1488),
    onSecondaryContainer = Color(0xFFE9DDFF),
    tertiary = Color(0xFF00E5FF),
    onTertiary = Color(0xFF00363D),
    background = CyberDarkBackground,
    onBackground = CyberOnBackground,
    surface = CyberDarkSurface,
    onSurface = CyberOnBackground,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = Color(0xFFD9C6EB),
    outline = Color(0xFF6B458C),
    outlineVariant = Color(0xFF3B1E54)
)

val EmeraldSerenityScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = EmeraldOnPrimary,
    primaryContainer = Color(0xFF06442B),
    onPrimaryContainer = Color(0xFFA5F3D1),
    secondary = EmeraldMintSecondary,
    onSecondary = Color(0xFF033B26),
    secondaryContainer = Color(0xFF0F5238),
    onSecondaryContainer = Color(0xFFC6F7E2),
    tertiary = Color(0xFFFBBF24),
    onTertiary = Color(0xFF422800),
    background = EmeraldDarkBackground,
    onBackground = EmeraldOnBackground,
    surface = EmeraldDarkSurface,
    onSurface = EmeraldOnBackground,
    surfaceVariant = EmeraldSurfaceVariant,
    onSurfaceVariant = Color(0xFFC5DFD3),
    outline = Color(0xFF41735C),
    outlineVariant = Color(0xFF244837)
)

@Composable
fun AuraTheme(
    themeMode: AppThemeMode = AppThemeMode.MIDNIGHT_ROSE,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.MIDNIGHT_ROSE -> MidnightRoseScheme
        AppThemeMode.CLAUDE_WARMTH -> ClaudeWarmthScheme
        AppThemeMode.GEMINI_NEBULA -> GeminiNebulaScheme
        AppThemeMode.CYBER_AMETHYST -> CyberAmethystScheme
        AppThemeMode.EMERALD_SERENITY -> EmeraldSerenityScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
