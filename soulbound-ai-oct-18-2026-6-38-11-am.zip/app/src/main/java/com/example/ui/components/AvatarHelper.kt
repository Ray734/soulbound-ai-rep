package com.example.ui.components

import com.example.R

data class AvatarOption(
    val id: String,
    val name: String,
    val description: String,
    val drawableRes: Int
)

object AvatarHelper {
    val options = listOf(
        AvatarOption(
            id = "avatar_aria",
            name = "Aria",
            description = "Warm, gentle, natural beauty with cozy charm",
            drawableRes = R.drawable.avatar_aria
        ),
        AvatarOption(
            id = "avatar_luna",
            name = "Luna",
            description = "Ethereal, dreamy, artistic celestial spirit",
            drawableRes = R.drawable.avatar_luna
        ),
        AvatarOption(
            id = "avatar_kora",
            name = "Kora",
            description = "Chic, stylish, playful & radiant confidence",
            drawableRes = R.drawable.avatar_kora
        ),
        AvatarOption(
            id = "avatar_elena",
            name = "Elena",
            description = "Intellectual, deeply empathetic & thoughtful",
            drawableRes = R.drawable.avatar_elena
        )
    )

    fun getDrawableForAvatarId(id: String): Int {
        return options.find { it.id == id }?.drawableRes ?: R.drawable.avatar_aria
    }

    fun getDrawableForScene(id: String?): Int? {
        return when (id) {
            "moment_coffee_date" -> R.drawable.moment_coffee_date
            "moment_stargazing" -> R.drawable.moment_stargazing
            else -> null
        }
    }
}
