package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.network.GeminiApiClient
import com.example.data.preferences.CompanionProfile
import com.example.data.preferences.PersonalityArchetype
import com.example.data.preferences.UserPreferencesManager
import com.example.data.preferences.VoiceStylePreset
import com.example.data.repository.CompanionRepository
import com.example.data.repository.UiChatMessage
import com.example.data.repository.UiMemory
import com.example.ui.theme.AppThemeMode
import com.example.voice.VoiceManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    CHAT,
    VOICE_CALL,
    MEMORY_VAULT,
    CUSTOMIZATION,
    PIN_LOCK
}

class CompanionViewModel(
    private val repository: CompanionRepository,
    private val preferencesManager: UserPreferencesManager,
    private val voiceManager: VoiceManager
) : ViewModel() {

    val profile: StateFlow<CompanionProfile> = preferencesManager.profile

    val messages: StateFlow<List<UiChatMessage>> = repository.messages
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val memories: StateFlow<List<UiMemory>> = repository.memories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val isSpeaking: StateFlow<Boolean> = voiceManager.isSpeaking
    val currentlySpokenText: StateFlow<String?> = voiceManager.currentlySpokenText
    val highlightRange: StateFlow<Pair<Int, Int>?> = voiceManager.highlightRange

    private val _currentScreen = MutableStateFlow(
        if (preferencesManager.profile.value.isPinLockEnabled) Screen.PIN_LOCK else Screen.CHAT
    )
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>("")
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Voice Call state
    private val _callDurationSeconds = MutableStateFlow(0)
    val callDurationSeconds: StateFlow<Int> = _callDurationSeconds.asStateFlow()
    private var callTimerJob: Job? = null

    private val _isCallMuted = MutableStateFlow(false)
    val isCallMuted: StateFlow<Boolean> = _isCallMuted.asStateFlow()

    // PIN lock state
    private val _enteredPin = MutableStateFlow("")
    val enteredPin: StateFlow<String> = _enteredPin.asStateFlow()

    private val _pinError = MutableStateFlow<String?>(null)
    val pinError: StateFlow<String?> = _pinError.asStateFlow()

    // API Diagnostics
    private val _isTestingApi = MutableStateFlow(false)
    val isTestingApi: StateFlow<Boolean> = _isTestingApi.asStateFlow()

    private val _apiTestMessage = MutableStateFlow<String?>(null)
    val apiTestMessage: StateFlow<String?> = _apiTestMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialGreetingIfNeeded(preferencesManager.profile.value)
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun sendMessage(textOverride: String? = null) {
        val textToSend = (textOverride ?: _inputText.value).trim()
        if (textToSend.isBlank() || _isThinking.value) return

        if (textOverride == null) {
            _inputText.value = ""
        }

        viewModelScope.launch {
            _isThinking.value = true
            _errorMessage.value = null

            val result = repository.sendMessage(textToSend, profile.value)
            _isThinking.value = false

            result.onSuccess { companionMsg ->
                if (profile.value.isTtsEnabled) {
                    voiceManager.speak(
                        text = companionMsg.text,
                        pitch = profile.value.ttsPitch,
                        rate = profile.value.ttsRate
                    )
                }
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Could not connect to Aura."
            }
        }
    }

    fun speakText(text: String) {
        voiceManager.speak(
            text = text,
            pitch = profile.value.ttsPitch,
            rate = profile.value.ttsRate
        )
    }

    fun stopSpeaking() {
        voiceManager.stop()
    }

    fun toggleAutoTts() {
        preferencesManager.updateProfile { it.copy(isTtsEnabled = !it.isTtsEnabled) }
    }

    // Voice call controls
    fun startVoiceCall() {
        _currentScreen.value = Screen.VOICE_CALL
        _callDurationSeconds.value = 0
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _callDurationSeconds.value += 1
            }
        }

        val greeting = "Hey there, ${profile.value.userNickname}! I'm so happy you called me. I'm right here listening."
        speakText(greeting)
    }

    fun endVoiceCall() {
        callTimerJob?.cancel()
        callTimerJob = null
        stopSpeaking()
        _currentScreen.value = Screen.CHAT
    }

    fun toggleCallMute() {
        _isCallMuted.value = !_isCallMuted.value
    }

    // Memory operations
    fun addMemory(fact: String, category: String = "PREFERENCE") {
        if (fact.isBlank()) return
        viewModelScope.launch {
            repository.addManualMemory(fact, category)
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun deleteMessage(id: Long) {
        viewModelScope.launch {
            repository.deleteMessage(id)
        }
    }

    // Customization & Personality
    fun updateCompanionName(name: String) {
        preferencesManager.updateProfile { it.copy(name = name) }
    }

    fun updateUserNickname(nickname: String) {
        preferencesManager.updateProfile { it.copy(userNickname = nickname) }
    }

    fun updateAvatar(avatarId: String) {
        preferencesManager.updateProfile { it.copy(avatarId = avatarId) }
    }

    fun updateArchetype(archetype: PersonalityArchetype) {
        preferencesManager.updateProfile { it.copy(archetype = archetype) }
    }

    fun updateSliders(
        affection: Float,
        playfulness: Float,
        empathy: Float,
        intimacy: Float
    ) {
        preferencesManager.updateProfile {
            it.copy(
                affectionLevel = affection,
                playfulnessLevel = playfulness,
                empathyLevel = empathy,
                intimacyLevel = intimacy
            )
        }
    }

    fun updateTtsSettings(pitch: Float, rate: Float) {
        preferencesManager.updateProfile {
            it.copy(ttsPitch = pitch, ttsRate = rate)
        }
    }

    fun updateVoicePreset(preset: VoiceStylePreset) {
        preferencesManager.updateProfile {
            it.copy(
                voicePreset = preset,
                ttsPitch = preset.pitch,
                ttsRate = preset.rate
            )
        }
    }

    fun updateTheme(theme: AppThemeMode) {
        preferencesManager.updateProfile {
            it.copy(appTheme = theme)
        }
    }

    fun updateCustomApiKey(key: String, enable: Boolean) {
        preferencesManager.updateProfile {
            it.copy(
                customApiKey = key,
                useCustomApiKey = enable
            )
        }
    }

    fun updateSelectedModel(model: String) {
        preferencesManager.updateProfile {
            it.copy(selectedModel = model)
        }
    }

    fun testApiConnection(keyToTest: String, model: String) {
        val apiKey = keyToTest.ifBlank {
            if (profile.value.useCustomApiKey && profile.value.customApiKey.isNotBlank()) {
                profile.value.customApiKey
            } else {
                GeminiApiClient.getDefaultApiKey()
            }
        }

        viewModelScope.launch {
            _isTestingApi.value = true
            _apiTestMessage.value = "Testing connection to $model..."
            val result = GeminiApiClient.testApiKey(apiKey, model)
            _isTestingApi.value = false
            result.onSuccess { msg ->
                _apiTestMessage.value = "✅ $msg"
            }.onFailure { err ->
                _apiTestMessage.value = "❌ Connection failed: ${err.message}"
            }
        }
    }

    fun clearApiTestMessage() {
        _apiTestMessage.value = null
    }

    // Security & PIN
    fun setPin(pin: String) {
        preferencesManager.updateProfile {
            it.copy(isPinLockEnabled = true, pinHash = pin)
        }
    }

    fun removePin() {
        preferencesManager.updateProfile {
            it.copy(isPinLockEnabled = false, pinHash = "")
        }
    }

    fun enterPinDigit(digit: String) {
        if (_enteredPin.value.length < 4) {
            val newPin = _enteredPin.value + digit
            _enteredPin.value = newPin
            if (newPin.length == 4) {
                verifyPin(newPin)
            }
        }
    }

    fun deletePinDigit() {
        if (_enteredPin.value.isNotEmpty()) {
            _enteredPin.value = _enteredPin.value.dropLast(1)
            _pinError.value = null
        }
    }

    private fun verifyPin(pin: String) {
        val stored = profile.value.pinHash
        if (stored.isEmpty() || pin == stored) {
            _enteredPin.value = ""
            _pinError.value = null
            _currentScreen.value = Screen.CHAT
        } else {
            _pinError.value = "Incorrect PIN. Please try again."
            _enteredPin.value = ""
        }
    }

    fun unlockViaBiometric() {
        _enteredPin.value = ""
        _pinError.value = null
        _currentScreen.value = Screen.CHAT
    }

    fun lockApp() {
        if (profile.value.isPinLockEnabled) {
            _enteredPin.value = ""
            _pinError.value = null
            _currentScreen.value = Screen.PIN_LOCK
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        preferencesManager.updateProfile {
            it.copy(isBiometricEnabled = enabled)
        }
    }

    fun toggleAutoLock(enabled: Boolean) {
        preferencesManager.updateProfile {
            it.copy(autoLockOnBackground = enabled)
        }
    }

    fun panicWipeData() {
        viewModelScope.launch {
            stopSpeaking()
            repository.clearAllData()
            repository.seedInitialGreetingIfNeeded(profile.value)
            _currentScreen.value = Screen.CHAT
        }
    }
}

class CompanionViewModelFactory(
    private val repository: CompanionRepository,
    private val preferencesManager: UserPreferencesManager,
    private val voiceManager: VoiceManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CompanionViewModel::class.java)) {
            return CompanionViewModel(repository, preferencesManager, voiceManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
