package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CustomizationScreen
import com.example.ui.screens.MemoryVaultScreen
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.VoiceCallScreen
import com.example.ui.theme.AuraTheme
import com.example.ui.viewmodel.CompanionViewModel
import com.example.ui.viewmodel.CompanionViewModelFactory
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    private var activeViewModel: CompanionViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AuraApplication
        val factory = CompanionViewModelFactory(
            repository = app.repository,
            preferencesManager = app.preferencesManager,
            voiceManager = app.voiceManager
        )

        setContent {
            val viewModel: CompanionViewModel = viewModel(factory = factory)
            activeViewModel = viewModel
            val profile by viewModel.profile.collectAsStateWithLifecycle()
            AuraTheme(themeMode = profile.appTheme) {
                AuraMainNavigation(viewModel = viewModel)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val vm = activeViewModel ?: return
        if (vm.profile.value.isPinLockEnabled && vm.profile.value.autoLockOnBackground) {
            vm.lockApp()
        }
    }
}

@Composable
fun AuraMainNavigation(viewModel: CompanionViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    Surface(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                Screen.PIN_LOCK -> PinLockScreen(viewModel = viewModel)
                Screen.CHAT -> ChatScreen(viewModel = viewModel)
                Screen.VOICE_CALL -> VoiceCallScreen(viewModel = viewModel)
                Screen.MEMORY_VAULT -> MemoryVaultScreen(viewModel = viewModel)
                Screen.CUSTOMIZATION -> CustomizationScreen(viewModel = viewModel)
            }
        }
    }
}
