package com.example.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.DialogInterface
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.core.content.ContextCompat

object BiometricAuthHelper {

    fun isBiometricAvailable(context: Context): Boolean {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return keyguardManager?.isKeyguardSecure == true || keyguardManager?.isDeviceSecure == true
    }

    fun promptBiometric(
        activity: Activity,
        title: String = "Unlock Aura Sanctuary",
        subtitle: String = "Confirm biometric or device credential to view private conversations",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val cancellationSignal = CancellationSignal()

            try {
                val promptBuilder = BiometricPrompt.Builder(activity)
                    .setTitle(title)
                    .setSubtitle(subtitle)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    promptBuilder.setDeviceCredentialAllowed(true)
                } else {
                    promptBuilder.setNegativeButton("Use PIN instead", ContextCompat.getMainExecutor(activity)) { _, _ ->
                        onError("Use PIN instead")
                    }
                }

                val prompt = promptBuilder.build()
                prompt.authenticate(
                    cancellationSignal,
                    ContextCompat.getMainExecutor(activity),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            super.onAuthenticationSucceeded(result)
                            onSuccess()
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                            super.onAuthenticationError(errorCode, errString)
                            onError(errString?.toString() ?: "Authentication error ($errorCode)")
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            onError("Biometric not recognized. Please try again or use PIN.")
                        }
                    }
                )
            } catch (e: Exception) {
                // If biometric prompt fails or unsupported in emulator, fallback to PIN
                onError(e.message ?: "Biometrics not available on this device")
            }
        } else {
            onError("Biometrics require Android 9.0 or higher. Please use your PIN.")
        }
    }
}
