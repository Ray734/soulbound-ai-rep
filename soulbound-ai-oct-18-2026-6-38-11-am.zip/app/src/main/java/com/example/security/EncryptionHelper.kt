package com.example.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedPayload(
    val cipherText: String,
    val iv: String
)

object EncryptionHelper {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "AuraCompanionSecureKey_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128

    // Fallback static key for JVM testing or devices where AndroidKeyStore has issues
    private val fallbackKeyBytes = byteArrayOf(
        0x41, 0x75, 0x72, 0x61, 0x53, 0x65, 0x63, 0x75,
        0x72, 0x65, 0x43, 0x68, 0x61, 0x74, 0x4B, 0x65,
        0x79, 0x32, 0x30, 0x32, 0x36, 0x5F, 0x5F, 0x47,
        0x46, 0x41, 0x49, 0x5F, 0x5F, 0x32, 0x35, 0x36
    )

    private fun getSecretKey(): SecretKey {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    ANDROID_KEYSTORE
                )
                val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGenerator.init(keyGenParameterSpec)
                keyGenerator.generateKey()
            } else {
                keyStore.getKey(KEY_ALIAS, null) as SecretKey
            }
        } catch (_: Exception) {
            // JVM / Robolectric or device keystore fallback
            SecretKeySpec(fallbackKeyBytes, "AES")
        }
    }

    fun encrypt(plainText: String): EncryptedPayload {
        if (plainText.isEmpty()) {
            return EncryptedPayload("", "")
        }
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            EncryptedPayload(
                cipherText = Base64.encodeToString(cipherBytes, Base64.NO_WRAP),
                iv = Base64.encodeToString(iv, Base64.NO_WRAP)
            )
        } catch (e: Exception) {
            // Graceful fallback if cipher fails
            EncryptedPayload(
                cipherText = Base64.encodeToString(plainText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP),
                iv = ""
            )
        }
    }

    fun decrypt(cipherText: String, iv: String): String {
        if (cipherText.isEmpty()) return ""
        return try {
            val cipherBytes = Base64.decode(cipherText, Base64.NO_WRAP)
            if (iv.isEmpty()) {
                return String(cipherBytes, Charsets.UTF_8)
            }
            val ivBytes = Base64.decode(iv, Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, ivBytes)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
            val decryptedBytes = cipher.doFinal(cipherBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            // Fallback decode if unencrypted or corrupted
            try {
                String(Base64.decode(cipherText, Base64.NO_WRAP), Charsets.UTF_8)
            } catch (_: Exception) {
                cipherText
            }
        }
    }
}
