package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.preferences.UserPreferencesManager
import com.example.data.repository.CompanionRepository
import com.example.voice.VoiceManager

class AuraApplication : Application() {
    lateinit var database: AppDatabase
        private set

    lateinit var preferencesManager: UserPreferencesManager
        private set

    lateinit var repository: CompanionRepository
        private set

    lateinit var voiceManager: VoiceManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        preferencesManager = UserPreferencesManager(this)
        repository = CompanionRepository(database, preferencesManager)
        voiceManager = VoiceManager(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        voiceManager.shutdown()
    }
}
