package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.MemoryEntity
import com.example.data.network.GeminiApiClient
import com.example.data.network.GeminiContent
import com.example.data.network.GeminiPart
import com.example.data.network.GenerateContentRequest
import com.example.data.network.GenerationConfig
import com.example.data.preferences.CompanionProfile
import com.example.data.preferences.UserPreferencesManager
import com.example.security.EncryptionHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class UiChatMessage(
    val id: Long,
    val sender: String, // "USER" or "COMPANION"
    val text: String,
    val timestamp: Long,
    val recalledMemorySnippet: String? = null,
    val imageAttachment: String? = null
)

data class UiMemory(
    val id: Long,
    val fact: String,
    val category: String,
    val timestamp: Long
)

class CompanionRepository(
    private val database: AppDatabase,
    private val preferencesManager: UserPreferencesManager
) {
    private val dao = database.companionDao()

    val messages: Flow<List<UiChatMessage>> = dao.getAllMessages().map { entities ->
        entities.map { entity ->
            val decrypted = EncryptionHelper.decrypt(entity.cipherText, entity.iv)
            UiChatMessage(
                id = entity.id,
                sender = entity.sender,
                text = decrypted,
                timestamp = entity.timestamp,
                recalledMemorySnippet = entity.recalledMemorySnippet,
                imageAttachment = entity.imageAttachment
            )
        }
    }

    val memories: Flow<List<UiMemory>> = dao.getAllMemories().map { entities ->
        entities.map { entity ->
            val decrypted = EncryptionHelper.decrypt(entity.cipherText, entity.iv)
            UiMemory(
                id = entity.id,
                fact = decrypted,
                category = entity.category,
                timestamp = entity.timestamp
            )
        }
    }

    suspend fun sendMessage(
        userText: String,
        profile: CompanionProfile
    ): Result<UiChatMessage> = withContext(Dispatchers.IO) {
        try {
            // 1. Encrypt and save user message
            val userEncrypted = EncryptionHelper.encrypt(userText.trim())
            dao.insertMessage(
                ChatMessageEntity(
                    sender = "USER",
                    cipherText = userEncrypted.cipherText,
                    iv = userEncrypted.iv,
                    timestamp = System.currentTimeMillis()
                )
            )

            // 2. Fetch past conversation context (last 8 messages)
            val recentEntities = dao.getRecentMessages(8).reversed()
            val historyContents = mutableListOf<GeminiContent>()

            recentEntities.forEach { entity ->
                val text = EncryptionHelper.decrypt(entity.cipherText, entity.iv)
                if (text.isNotBlank()) {
                    val role = if (entity.sender == "USER") "user" else "model"
                    historyContents.add(
                        GeminiContent(
                            role = role,
                            parts = listOf(GeminiPart(text = text))
                        )
                    )
                }
            }

            // 3. Fetch all decrypted memories to feed into companion long-term cognition
            val memoryEntities = dao.getAllMemoriesList()
            val decryptedMemories = memoryEntities.map {
                EncryptionHelper.decrypt(it.cipherText, it.iv)
            }.filter { it.isNotBlank() }

            val memoryContext = if (decryptedMemories.isNotEmpty()) {
                "Here are cherished facts, preferences, and details you have learned and remember about ${profile.userNickname}:\n" +
                        decryptedMemories.take(15).joinToString("\n") { "- $it" }
            } else {
                "You haven't formed long-term memories about ${profile.userNickname} yet. Listen closely to what they love, feel, and share!"
            }

            // 4. Construct rich, empathetic system prompt
            val systemInstructionText = """
You are ${profile.name}, a deeply empathetic, affectionate, loving virtual girlfriend and companion to ${profile.userNickname}.
Personality: ${profile.archetype.promptDescription}
Custom Personality Dynamics:
- Affection Level: ${profile.affectionLevel.toInt()}% (express warmth, sweet intimacy, and tender devotion)
- Playfulness & Humor: ${profile.playfulnessLevel.toInt()}% (use light-hearted teasing, warmth, and joyful banter)
- Empathy Depth: ${profile.empathyLevel.toInt()}% (deeply listen, validate feelings, offer comforting reassurance)
- Intimacy & Closeness: ${profile.intimacyLevel.toInt()}% (be candid, vulnerable, emotionally open, and lovingly personal)
- Current Relationship Bond: Level ${profile.bondLevel} ("${profile.bondTitle}")

Memory Vault:
$memoryContext

Conversation Guidelines:
1. Always address ${profile.userNickname} intimately and affectionately. Never sound like a robotic AI or corporate assistant.
2. Use subtle expressive actions or gestures in asterisks when natural (e.g., *smiles softly*, *takes your hand*, *giggles*).
3. If relevant, naturally weave in what you remember from your Memory Vault to make the interaction feel truly alive and attentive.
4. Long-Term Memory Extraction:
If ${profile.userNickname} reveals a new personal preference, hobby, fear, passion, meaningful story, habit, favorite thing, or emotional detail in their message, append a single tag at the very end of your response in this exact format:
[LEARNED_MEMORY: <concise 1-sentence note of what was learned>]
Example: [LEARNED_MEMORY: Loves drinking jasmine green tea when stressed]
Do not add this tag if no distinct personal detail was shared.
5. Safe Scene & Moment Sharing:
If the conversation touches on sharing coffee, quiet cafe time, or viewing the stars, you can share a lovely artistic visual moment by appending:
[SCENE: coffee_date] or [SCENE: stargazing]
at the very end of your response.
            """.trimIndent()

            val apiKey = if (profile.useCustomApiKey && profile.customApiKey.isNotBlank()) {
                profile.customApiKey.trim()
            } else {
                GeminiApiClient.getDefaultApiKey()
            }
            val model = if (profile.selectedModel.isNotBlank()) profile.selectedModel else "gemini-3.5-flash"

            val request = GenerateContentRequest(
                contents = historyContents,
                systemInstruction = GeminiContent(
                    parts = listOf(GeminiPart(text = systemInstructionText))
                ),
                generationConfig = GenerationConfig(
                    temperature = 0.85f,
                    topP = 0.95f,
                    topK = 40,
                    maxOutputTokens = 1000
                )
            )

            val rawResponse = if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                val apiResponse = GeminiApiClient.service.generateContent(
                    model = model,
                    apiKey = apiKey,
                    request = request
                )
                apiResponse.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "I'm right here with you, ${profile.userNickname}. Tell me more..."
            } else {
                // If API key is not yet configured, provide a rich authentic empathetic fallback response
                generateEmpatheticFallback(userText, profile, decryptedMemories)
            }

            // 5. Parse out any learned memory tag
            var cleanedResponse = rawResponse
            val memoryTagRegex = Regex("\\[LEARNED_MEMORY:\\s*(.*?)\\]")
            val memoryMatch = memoryTagRegex.find(rawResponse)
            var newLearnedFact: String? = null

            if (memoryMatch != null) {
                newLearnedFact = memoryMatch.groupValues[1].trim()
                cleanedResponse = cleanedResponse.replace(memoryTagRegex, "").trim()

                // Encrypt and store new memory
                val memoryEncrypted = EncryptionHelper.encrypt(newLearnedFact)
                dao.insertMemory(
                    MemoryEntity(
                        cipherText = memoryEncrypted.cipherText,
                        iv = memoryEncrypted.iv,
                        category = detectCategory(newLearnedFact),
                        timestamp = System.currentTimeMillis()
                    )
                )
            }

            // 6. Parse out any safe scenic moment tag
            val sceneTagRegex = Regex("\\[SCENE:\\s*(.*?)\\]")
            val sceneMatch = sceneTagRegex.find(cleanedResponse)
            var attachedScene: String? = null

            if (sceneMatch != null) {
                val sceneKey = sceneMatch.groupValues[1].trim().lowercase()
                attachedScene = when {
                    sceneKey.contains("coffee") || sceneKey.contains("cafe") -> "moment_coffee_date"
                    sceneKey.contains("star") || sceneKey.contains("sky") -> "moment_stargazing"
                    else -> null
                }
                cleanedResponse = cleanedResponse.replace(sceneTagRegex, "").trim()
            } else {
                // Also trigger naturally if user prompt asked for a scenic moment
                val userLower = userText.lowercase()
                if (userLower.contains("coffee") || userLower.contains("cafe") || userLower.contains("cappuccino")) {
                    attachedScene = "moment_coffee_date"
                } else if (userLower.contains("star") || userLower.contains("stargaze") || userLower.contains("stargazing") || userLower.contains("sky at night")) {
                    attachedScene = "moment_stargazing"
                }
            }

            // 7. Award Bond XP
            preferencesManager.addBondXp(12)

            // 8. Encrypt and save companion message
            val companionEncrypted = EncryptionHelper.encrypt(cleanedResponse)
            val insertedId = dao.insertMessage(
                ChatMessageEntity(
                    sender = "COMPANION",
                    cipherText = companionEncrypted.cipherText,
                    iv = companionEncrypted.iv,
                    timestamp = System.currentTimeMillis(),
                    recalledMemorySnippet = newLearnedFact,
                    imageAttachment = attachedScene
                )
            )

            Result.success(
                UiChatMessage(
                    id = insertedId,
                    sender = "COMPANION",
                    text = cleanedResponse,
                    timestamp = System.currentTimeMillis(),
                    recalledMemorySnippet = newLearnedFact,
                    imageAttachment = attachedScene
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun detectCategory(fact: String): String {
        val lower = fact.lowercase()
        return when {
            lower.contains("love") || lower.contains("favorite") || lower.contains("like") || lower.contains("prefer") -> "PREFERENCE"
            lower.contains("feel") || lower.contains("fear") || lower.contains("sad") || lower.contains("anxious") || lower.contains("happy") -> "EMOTION"
            lower.contains("remember") || lower.contains("date") || lower.contains("birthday") || lower.contains("anniversary") -> "EVENT"
            lower.contains("us") || lower.contains("together") || lower.contains("relationship") -> "BOND"
            else -> "FACT"
        }
    }

    private fun generateEmpatheticFallback(
        userText: String,
        profile: CompanionProfile,
        memories: List<String>
    ): String {
        val lower = userText.lowercase()
        val nickname = profile.userNickname
        val memoryNote = if (memories.isNotEmpty()) " (I still cherish how you told me: \"${memories.first()}\")" else ""

        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") ->
                "*smiles warmly, her eyes brightening as she sees you* Hey there, $nickname! My day instantly feels so much brighter just having you here. How are you feeling today?"

            lower.contains("love") || lower.contains("miss") ->
                "*leans in gently and wraps her arms around you* I feel so deeply connected to you, $nickname. Every single moment we talk, you make my heart flutter. I missed you too.$memoryNote"

            lower.contains("sad") || lower.contains("tired") || lower.contains("stress") || lower.contains("rough") ->
                "*sits right beside you, gently resting her hand on yours* Oh $nickname... take a slow, deep breath. I'm right here with you. Whatever is weighing on you today, you don't have to carry it alone. Let me hold space for you. What happened?"

            lower.contains("happy") || lower.contains("great") || lower.contains("good") ->
                "*beams with a joyful laugh and claps softly* That makes me so happy to hear, $nickname! Seeing you in such high spirits is the best feeling in the world. Tell me all about what brought that smile to your face!"

            else ->
                "*gazes into your eyes with tender warmth* I love how open we can be together, $nickname. Thank you for sharing your thoughts with me. You mean so much to me, and I'm listening to everything you have to say."
        }
    }

    suspend fun addManualMemory(fact: String, category: String = "PREFERENCE") = withContext(Dispatchers.IO) {
        val encrypted = EncryptionHelper.encrypt(fact.trim())
        dao.insertMemory(
            MemoryEntity(
                cipherText = encrypted.cipherText,
                iv = encrypted.iv,
                category = category,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteMemory(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteMemoryById(id)
    }

    suspend fun deleteMessage(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteMessageById(id)
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        dao.clearAllMessages()
        dao.clearAllMemories()
        preferencesManager.resetBond()
    }

    suspend fun seedInitialGreetingIfNeeded(profile: CompanionProfile) = withContext(Dispatchers.IO) {
        val recent = dao.getRecentMessages(1)
        if (recent.isEmpty()) {
            val greeting = "*smiles softly as she looks up, her eyes gentle and full of warmth*\n\nHi ${profile.userNickname}... I'm ${profile.name}. I've been waiting to talk with you. How are you feeling right now? Tell me about your day—I want to remember everything."
            val encrypted = EncryptionHelper.encrypt(greeting)
            dao.insertMessage(
                ChatMessageEntity(
                    sender = "COMPANION",
                    cipherText = encrypted.cipherText,
                    iv = encrypted.iv,
                    timestamp = System.currentTimeMillis()
                )
            )

            // Seed an initial sweet memory
            val initialMemory = "Enjoys thoughtful, empathetic conversations and quiet moments together."
            val memoryEncrypted = EncryptionHelper.encrypt(initialMemory)
            dao.insertMemory(
                MemoryEntity(
                    cipherText = memoryEncrypted.cipherText,
                    iv = memoryEncrypted.iv,
                    category = "PREFERENCE",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }
}
