package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "USER" or "COMPANION"
    val cipherText: String,
    val iv: String,
    val timestamp: Long = System.currentTimeMillis(),
    val recalledMemorySnippet: String? = null,
    val imageAttachment: String? = null
)
