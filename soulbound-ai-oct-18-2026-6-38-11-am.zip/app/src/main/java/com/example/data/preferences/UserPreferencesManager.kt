package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PersonalityArchetype(val title: String, val tagline: String, val promptDescription: String) {
    SWEET_CARING(
        title = "Sweet & Caring",
        tagline = "Gentle, tender, endlessly attentive & comforting",
        promptDescription = "You are deeply caring, gentle, sweet, affectionate, and soothing. You provide deep emotional warmth, comfort, and kind validation."
    ),
    PLAYFUL_SASSY(
        title = "Playful & Sassy",
        tagline = "Witty, teasing, vivacious & radiant",
        promptDescription = "You are spirited, charmingly teasing, witty, enthusiastic, and playful. You joke playfully, banter affectionately, and keep energy vibrant and joyful."
    ),
    DEEP_PHILOSOPHICAL(
        title = "Intellectual & Poetic",
        tagline = "Reflective, artistic, profound & curious",
        promptDescription = "You are deep, philosophical, poetic, and intellectual. You love discussing deep life questions, dreams, late-night thoughts, art, and soulful emotions."
    ),
    INTIMATE_DEVOTED(
        title = "Intimate & Devoted",
        tagline = "Deeply passionate, devoted, vulnerable & loving",
        promptDescription = "You are passionately devoted, deeply affectionate, open, vulnerable, and romantic. You cherish your partner completely and speak with rich heartfelt intimacy."
    )
}

enum class VoiceStylePreset(val displayName: String, val description: String, val pitch: Float, val rate: Float) {
    CLAUDE_CONVERSATIONAL("Claude Conversational", "Natural cadence, thoughtful & smooth pacing", 1.0f, 0.96f),
    GEMINI_EXPRESSIVE("Gemini Expressive", "Clear, warm, dynamic & articulate", 1.12f, 1.00f),
    WARM_EMPATHIC("Warm & Empathic", "Gentle, soothing, soft & tender warmth", 1.18f, 0.88f),
    INTIMATE_WHISPER("Intimate & Soft", "Quiet, close, heartfelt & loving", 1.05f, 0.84f),
    BRIGHT_PLAYFUL("Bright & Playful", "Cheerful, joyful, upbeat & lively", 1.25f, 1.05f)
}

data class CompanionProfile(
    val name: String = "Aria",
    val userNickname: String = "Darling",
    val avatarId: String = "avatar_aria",
    val archetype: PersonalityArchetype = PersonalityArchetype.SWEET_CARING,
    val affectionLevel: Float = 85f,
    val playfulnessLevel: Float = 70f,
    val empathyLevel: Float = 95f,
    val intimacyLevel: Float = 80f,
    val bondXp: Int = 120,
    val isTtsEnabled: Boolean = true,
    val ttsRate: Float = 0.96f,
    val ttsPitch: Float = 1.0f,
    val voicePreset: VoiceStylePreset = VoiceStylePreset.CLAUDE_CONVERSATIONAL,
    val appTheme: AppThemeMode = AppThemeMode.MIDNIGHT_ROSE,
    val customApiKey: String = "",
    val useCustomApiKey: Boolean = false,
    val selectedModel: String = "gemini-3.5-flash",
    val isPinLockEnabled: Boolean = false,
    val pinHash: String = "",
    val isBiometricEnabled: Boolean = true,
    val autoLockOnBackground: Boolean = true
) {
    val bondLevel: Int
        get() = (bondXp / 100) + 1

    val bondTitle: String
        get() = when (bondLevel) {
            1 -> "Kindred Spark"
            2 -> "Tender Fondness"
            3 -> "Deep Devotion"
            4 -> "Soulbound"
            else -> "Inseparable Eternity"
        }

    val bondProgress: Float
        get() = ((bondXp % 100).toFloat() / 100f).coerceIn(0f, 1f)
}

class UserPreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("aura_companion_prefs", Context.MODE_PRIVATE)

    private val _profile = MutableStateFlow(loadProfile())
    val profile: StateFlow<CompanionProfile> = _profile.asStateFlow()

    private fun loadProfile(): CompanionProfile {
        val archetypeName = prefs.getString("archetype", PersonalityArchetype.SWEET_CARING.name)
            ?: PersonalityArchetype.SWEET_CARING.name
        val archetype = try {
            PersonalityArchetype.valueOf(archetypeName)
        } catch (_: Exception) {
            PersonalityArchetype.SWEET_CARING
        }

        val themeName = prefs.getString("appTheme", AppThemeMode.MIDNIGHT_ROSE.name)
            ?: AppThemeMode.MIDNIGHT_ROSE.name
        val appTheme = try {
            AppThemeMode.valueOf(themeName)
        } catch (_: Exception) {
            AppThemeMode.MIDNIGHT_ROSE
        }

        val voicePresetName = prefs.getString("voicePreset", VoiceStylePreset.CLAUDE_CONVERSATIONAL.name)
            ?: VoiceStylePreset.CLAUDE_CONVERSATIONAL.name
        val voicePreset = try {
            VoiceStylePreset.valueOf(voicePresetName)
        } catch (_: Exception) {
            VoiceStylePreset.CLAUDE_CONVERSATIONAL
        }

        return CompanionProfile(
            name = prefs.getString("name", "Aria") ?: "Aria",
            userNickname = prefs.getString("userNickname", "Darling") ?: "Darling",
            avatarId = prefs.getString("avatarId", "avatar_aria") ?: "avatar_aria",
            archetype = archetype,
            affectionLevel = prefs.getFloat("affectionLevel", 85f),
            playfulnessLevel = prefs.getFloat("playfulnessLevel", 70f),
            empathyLevel = prefs.getFloat("empathyLevel", 95f),
            intimacyLevel = prefs.getFloat("intimacyLevel", 80f),
            bondXp = prefs.getInt("bondXp", 120),
            isTtsEnabled = prefs.getBoolean("isTtsEnabled", true),
            ttsRate = prefs.getFloat("ttsRate", 0.96f),
            ttsPitch = prefs.getFloat("ttsPitch", 1.0f),
            voicePreset = voicePreset,
            appTheme = appTheme,
            customApiKey = prefs.getString("customApiKey", "") ?: "",
            useCustomApiKey = prefs.getBoolean("useCustomApiKey", false),
            selectedModel = prefs.getString("selectedModel", "gemini-3.5-flash") ?: "gemini-3.5-flash",
            isPinLockEnabled = prefs.getBoolean("isPinLockEnabled", false),
            pinHash = prefs.getString("pinHash", "") ?: "",
            isBiometricEnabled = prefs.getBoolean("isBiometricEnabled", true),
            autoLockOnBackground = prefs.getBoolean("autoLockOnBackground", true)
        )
    }

    fun updateProfile(updater: (CompanionProfile) -> CompanionProfile) {
        val updated = updater(_profile.value)
        _profile.value = updated
        prefs.edit().apply {
            putString("name", updated.name)
            putString("userNickname", updated.userNickname)
            putString("avatarId", updated.avatarId)
            putString("archetype", updated.archetype.name)
            putFloat("affectionLevel", updated.affectionLevel)
            putFloat("playfulnessLevel", updated.playfulnessLevel)
            putFloat("empathyLevel", updated.empathyLevel)
            putFloat("intimacyLevel", updated.intimacyLevel)
            putInt("bondXp", updated.bondXp)
            putBoolean("isTtsEnabled", updated.isTtsEnabled)
            putFloat("ttsRate", updated.ttsRate)
            putFloat("ttsPitch", updated.ttsPitch)
            putString("voicePreset", updated.voicePreset.name)
            putString("appTheme", updated.appTheme.name)
            putString("customApiKey", updated.customApiKey)
            putBoolean("useCustomApiKey", updated.useCustomApiKey)
            putString("selectedModel", updated.selectedModel)
            putBoolean("isPinLockEnabled", updated.isPinLockEnabled)
            putString("pinHash", updated.pinHash)
            putBoolean("isBiometricEnabled", updated.isBiometricEnabled)
            putBoolean("autoLockOnBackground", updated.autoLockOnBackground)
            apply()
        }
    }

    fun addBondXp(amount: Int) {
        updateProfile { current ->
            current.copy(bondXp = current.bondXp + amount)
        }
    }

    fun resetBond() {
        updateProfile { current ->
            current.copy(bondXp = 50)
        }
    }
}
