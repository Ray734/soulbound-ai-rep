package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "companion_memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cipherText: String,
    val iv: String,
    val category: String = "PREFERENCE", // PREFERENCE, EMOTION, FACT, BOND, EVENT
    val timestamp: Long = System.currentTimeMillis()
)
