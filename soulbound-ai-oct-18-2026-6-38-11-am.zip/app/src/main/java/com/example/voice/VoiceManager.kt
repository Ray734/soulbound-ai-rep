package com.example.voice

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class VoiceManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentlySpokenText = MutableStateFlow<String?>(null)
    val currentlySpokenText: StateFlow<String?> = _currentlySpokenText.asStateFlow()

    private val _highlightRange = MutableStateFlow<Pair<Int, Int>?>(null)
    val highlightRange: StateFlow<Pair<Int, Int>?> = _highlightRange.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isInitialized = true
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentlySpokenText.value = null
                    _highlightRange.value = null
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentlySpokenText.value = null
                    _highlightRange.value = null
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                    _currentlySpokenText.value = null
                    _highlightRange.value = null
                }

                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    super.onRangeStart(utteranceId, start, end, frame)
                    _highlightRange.value = Pair(start, end)
                }
            })
        }
    }

    fun speak(text: String, pitch: Float = 1.0f, rate: Float = 0.96f) {
        if (!isInitialized || tts == null) return

        stop()

        // Strip action asterisks e.g. *smiles softly* or *whispers* for clean conversational TTS speech
        val cleanedText = cleanForSpeech(text)
        if (cleanedText.isBlank()) return

        tts?.setPitch(pitch.coerceIn(0.5f, 2.0f))
        tts?.setSpeechRate(rate.coerceIn(0.5f, 2.0f))

        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle()
        _currentlySpokenText.value = cleanedText
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stop() {
        if (tts != null && isInitialized) {
            try {
                tts?.stop()
            } catch (_: Exception) {}
        }
        _isSpeaking.value = false
        _currentlySpokenText.value = null
        _highlightRange.value = null
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }

    companion object {
        fun cleanForSpeech(input: String): String {
            // Remove asterisk actions: *smiles warmly*
            val withoutAsterisks = input.replace(Regex("\\*.*?\\*"), " ")
            // Remove parenthetical actions: (giggles)
            val withoutParentheses = withoutAsterisks.replace(Regex("\\(.*?\\)"), " ")
            // Remove special formatting artifacts
            return withoutParentheses
                .replace(Regex("[#_~`]"), "")
                .replace(Regex("\\s+"), " ")
                .trim()
        }
    }
}
